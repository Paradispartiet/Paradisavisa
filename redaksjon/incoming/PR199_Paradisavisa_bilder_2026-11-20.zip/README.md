# Paradisavisa – PR #199 – billedleveranse

Tre ferdig eksporterte 16:9 WebP-hovedbilder (1600 × 900 px), og tre 512 × 288-miniatyrer.

**Viktig:** Alle er KI-genererte redaksjonelle illustrasjoner og må merkes som dette; ingen er dokumentarfoto fra en faktisk hendelse. Bildene i denne pakken er tilknyttet arbeidsutkastene i PR #199; ingen er automatisk overført til GitHub, avisen eller sosiale medier.

Bruk eksakt filnavn i `manifest.json`. Når godkjent og lastet opp i `Bilder/Artikler/` i samme PR, oppdater artikkelbildene (src, alt, width, height), Open Graph og Twitter-bilder før publisering. Bytt kildebildene i arbeidsutkastene ut med de nye WebP-filene.
